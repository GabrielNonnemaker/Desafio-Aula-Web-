//código do carro

let xCarros = [700, 700, 700, 700, 700, 700]; 
let yCarros = [55, 125, 195, 265, 335, 405];
let velocidadeCarros =[6, 4.5, 5.6, 4, 4.7, 6.2];
let comprimentoCarro = 75;
let alturaCarro = 45;

function mostraCarro(){
    for(let i = 0; i < imagemCarros.length; i++){
      image(imagemCarros[i], xCarros[i], yCarros[i], comprimentoCarro, alturaCarro); 
    }
}

function movimentaCarro(){
  for (let i = 0; i < imagemCarros.length; i++){
  xCarros[i] -= velocidadeCarros[i];
  }
}

function voltaPosicaoInicialDoCarro(){
  for (let i = 0; i < imagemCarros.length; i++){
  if (passouTodaATela(xCarros[i])){
    xCarros[i] = 830;
    }
  }
}

function passouTodaATela(xCarro){
    return xCarro < - 50;
  }
